package ar.org.centro8.curso.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.curso.java.repositories.AlumnosRespository;
import ar.org.centro8.curso.java.repositories.CursoRepository;

@Controller
public class AlumnoController {

    @Autowired
    private CursoRepository cr;

    @Autowired
    private AlumnosRespository ar;
    
    private String mensaje="Ingrese un nuevo alumno";


    @GetMapping("/alumnos")
    public String getAlumnos(Model model) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cursos", cr.findAll());
        return "alumnos";
    }
}
