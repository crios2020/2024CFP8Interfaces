package ar.org.centro8.curso.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.CursoRepository;
import jakarta.websocket.server.PathParam;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class ControllerCurso {

    @Autowired
    private CursoRepository cr;
    
    private String mensaje="Ingrese un nuevo curso";

    @GetMapping("/cursos")
    public String getCursos(Model model, 
        @RequestParam(name="buscar",defaultValue = "")String buscar) {
        Curso curso=new Curso();
        model.addAttribute("dias", List.of(Dia.values()));
        model.addAttribute("turnos", List.of(Turno.values()));
        model.addAttribute("curso", curso);
        model.addAttribute("mensaje", mensaje);
        //model.addAttribute("cursos", cr.findAll());
        model.addAttribute("cursos", 
                        ((List<Curso>)cr.findAll())
                                    .stream()
                                    .filter(c->c
                                                    .getTitulo()
                                                    .toLowerCase()
                                                    .contains(buscar.toLowerCase()))
                                    .toList());
        return "cursos";
        /*
         * create table alumnos (
                id int auto_increment primary key,
                nombre varchar(25) not null check(length(nombre)>=3),
                apellido varchar(25) not null check(length(apellido)>=3),
                edad int not null check(edad>=18 and edad<=120),
                idCurso int not null,
                activo boolean default true
            );

            alter table alumnos
                add constraint FK_Alumnos_Cursos
                foreign key (idCurso) 
                references cursos(id);
         */
    }

    @PostMapping("/save")
    public String postMethodName(@ModelAttribute Curso curso) {
        cr.save(curso);
        if(curso.getId()>0){
            mensaje="Se guardo el curso id "+curso.getId();
        }else{
            mensaje="No se pudo guardar el curso!";
        }
        return "redirect:cursos";
    }
    
}
