function request(){
    //console.log("Se ejecuto una función!")

    //user = document.getElementById("user").value;
    //pass = document.getElementById("pass").value;

    console.log(user.value)
    console.log(pass.value)

    var url="http://localhost:8080/login?user="+user.value+"&pass="+pass.value
    axios.post(url)
        .then(function (response) {
            //console.log(response);
            //console.log(response.data);
            document.getElementById("resultado").innerHTML=response.data;
        })
        .catch(function (error) {
            //console.log(error);
        });
}