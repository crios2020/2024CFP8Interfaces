package ar.org.centro8.curso.java.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.AlumnosRespository;
import ar.org.centro8.curso.java.repositories.CursoRepository;

@Controller
public class AlumnoController {

    @Autowired
    private CursoRepository cr;

    @Autowired
    private AlumnosRespository ar;
    
    private String mensaje="Ingrese un nuevo alumno";

    @GetMapping("/alumnos")
    public String getAlumnos(Model model) {
        Alumno alumno=new Alumno();
        alumno.setEdad(18);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cursos", cr.findAll());
        model.addAttribute("alumno", alumno);
        model.addAttribute("alumnos", ar.findAll());
        Map<Integer, Curso> mapaCursos=new LinkedHashMap();
            cr
                .findAll()
                .forEach(c->mapaCursos.put(c.getId(), c));
        model.addAttribute("mapaCursos", mapaCursos);
        return "alumnos";
    }

    @PostMapping("/saveAlumno")
    public String postMethodName(@ModelAttribute Alumno alumno) {
        //System.out.println("***************************************************");
        //System.out.println(alumno);
        //System.out.println("***************************************************");
        ar.save(alumno);
        //System.out.println("***************************************************");
        //System.out.println(alumno);
        //System.out.println("***************************************************");
        if(alumno.getId()>0){
            mensaje="Se guardo el alumno id "+alumno.getId();
        }else{
            mensaje="No se pudo guardar el alumno!";
        }
        return "redirect:alumnos";
    }

}
