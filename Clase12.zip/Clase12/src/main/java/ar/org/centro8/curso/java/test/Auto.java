package ar.org.centro8.curso.java.test;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Auto {
    private String marca;
    private String modelo;
    private String color;    
}
