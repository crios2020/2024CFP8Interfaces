package ar.org.centro8.curso.java.test;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Empleado implements Comparable<Empleado> {
    private int nroLegajo;
    private String nombre;
    private String apellido;

    @Override
    public int compareTo(Empleado para) {
        String thisEmpleado=this.getNroLegajo()+", "+this.getApellido()+", "+this.getNombre();
        String paraEmpleado=para.getNroLegajo()+", "+para.getApellido()+", "+para.getNombre();
        return thisEmpleado.compareTo(paraEmpleado);
    }
 
}
