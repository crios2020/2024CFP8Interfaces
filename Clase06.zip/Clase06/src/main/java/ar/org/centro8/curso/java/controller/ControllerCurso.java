package ar.org.centro8.curso.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.CursoRepository;

@Controller
public class ControllerCurso {

    @Autowired
    private CursoRepository cr;

    @GetMapping("/cursos")
    public String getCursos() {
        System.out.println("********************************");
        System.out.println(cr.count());
        Curso curso=new Curso(null,"Java","Gomes",Dia.JUEVES,Turno.NOCHE);
        cr.save(curso);
        
        System.out.println(curso);
        System.out.println(cr.count());
        cr.findAll().forEach(System.out::println);
        System.out.println("********************************");
        return "cursos";
        /*
         * create table alumnos (
                id int auto_increment primary key,
                nombre varchar(25) not null check(length(nombre)>=3),
                apellido varchar(25) not null check(length(apellido)>=3),
                edad int not null check(edad>=18 and edad<=120),
                idCurso int not null,
                activo boolean default true
            );

            alter table alumnos
                add constraint FK_Alumnos_Cursos
                foreign key (idCurso) 
                references cursos(id);
         */
    }
}
