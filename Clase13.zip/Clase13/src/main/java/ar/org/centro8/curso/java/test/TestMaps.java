package ar.org.centro8.curso.java.test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMaps {
    public static void main(String[] args) {
        
        //Declaración
        Map<String,String>mapaSemana;

        //implementación
        //mapaSemana=new LinkedHashMap();
        //mapaSemana=new TreeMap();
        mapaSemana=new HashMap();

        //App
        mapaSemana.put("lu", "Lunes");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");
        System.out.println(mapaSemana.get("ma"));
        mapaSemana.forEach((k,v)->System.out.println(k+": "+v));


        Map<String,Auto> mapaPersonasAutos;
        //mapaPersonasAutos=new LinkedHashMap();
        //mapaPersonasAutos=new HashMap();
        mapaPersonasAutos=new TreeMap();

        mapaPersonasAutos.put("Nahuel", new Auto("Ford", "Ka", "Negro"));
        mapaPersonasAutos.put("Ana", new Auto("Fiat", "Idea", "Gris"));
        mapaPersonasAutos.put("Gabriel", new Auto("VW", "Gol", "Azul"));
        mapaPersonasAutos.put("Beatriz", new Auto("Renault", "Sandero", "Bordo"));
        mapaPersonasAutos.put("Ana", new Auto("Renault", "Clio", "Blanco"));

        System.out.println(mapaPersonasAutos.get("Ana"));
        mapaPersonasAutos.forEach((k,v)->System.out.println(k+": "+v));
        
        Map<Empleado,Auto>mapaEmpleadosAutos;
        //mapaEmpleadosAutos=new LinkedHashMap();
        //mapaEmpleadosAutos=new HashMap();
        mapaEmpleadosAutos=new TreeMap();

        Empleado empleado1=new Empleado(1, "Ana", "Viel");
        Empleado empleado2=new Empleado(2, "Hugo", "Perez");
        Empleado empleado3=new Empleado(3, "Matías", "Veron");
        Empleado empleado4=new Empleado(4, "Rodolfo", "Garcia");
        Auto auto1=new Auto("Ford", "Ka", "Negro");
        Auto auto2=new Auto("Fiat", "Idea", "Gris");
        Auto auto3=new Auto("VW", "Gol", "Azul");
        Auto auto4=new Auto("Renault", "Clio", "Blanco");
        mapaEmpleadosAutos.put(empleado1, auto4);
        mapaEmpleadosAutos.put(empleado2, auto3);
        mapaEmpleadosAutos.put(empleado3, auto2);
        mapaEmpleadosAutos.put(empleado4, auto1);

        System.out.println(mapaEmpleadosAutos.get(empleado2));
        mapaEmpleadosAutos.forEach((e,a)->System.out.println(e+" "+a));



    }
}
