-- Active: 1723855658210@@127.0.0.1@3306@negocio
DROP DATABASE IF EXISTS negocio;
CREATE DATABASE negocio;
USE negocio;

DROP TABLE IF EXISTS detalles;
DROP TABLE IF EXISTS facturas;
DROP TABLE IF EXISTS articulos;
DROP TABLE IF EXISTS clientes;

CREATE TABLE clientes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL CHECK(LENGTH(nombre)>=3),
    apellido VARCHAR(25) NOT NULL CHECK(LENGTH(apellido)>=3),
    tipo_doc ENUM('DNI','LC','LE','PASS') NOT NULL DEFAULT 'DNI',
    numero_doc VARCHAR(10) NOT NULL CHECK(LENGTH(numero_doc)>=5),
    fenaci DATE NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(60),
    comentarios VARCHAR(250),
    activo BOOLEAN NOT NULL DEFAULT true
);

ALTER TABLE clientes
    ADD CONSTRAINT U_Clientes_Documento
    UNIQUE(tipo_doc, numero_doc);

CREATE TABLE articulos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(25) NOT NULL CHECK(LENGTH(descripcion)>=3),
    costo DOUBLE NOT NULL CHECK(costo>=0),
    precio DOUBLE NOT NULL CHECK(precio>=costo),
    stock INT NOT NULL CHECK(stock>=0),
    stock_min INT NOT NULL CHECK(stock_min>=0),
    stock_max INT NOT NULL CHECK(stock_max>=stock_min)
);

CREATE TABLE facturas(
    id INT AUTO_INCREMENT PRIMARY KEY,
    letra ENUM('A','B','C') NOT NULL,
    numero INT NOT NULL CHECK(numero>=0),
    fecha DATE NOT NULL DEFAULT CURDATE(),
    monto DOUBLE CHECK(monto>=0),
    id_cliente INT NOT NULL
);

ALTER TABLE facturas
    ADD CONSTRAINT U_Facturas_Letra_Numero
    UNIQUE(letra, numero);

ALTER TABLE facturas
    ADD CONSTRAINT FK_Facturas_Id_cliente
    FOREIGN KEY(id_cliente)
    REFERENCES clientes(id);

CREATE TABLE detalles(
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_articulo INT NOT NULL,
    id_factura INT NOT NULL,
    cantidad INT NOT NULL CHECK(cantidad>=0),
    valor_unidad DOUBLE NOT NULL CHECK(valor_unidad>=0)
);

ALTER TABLE detalles
    ADD CONSTRAINT FK_Detalles_Facturas
    FOREIGN KEY (id_factura)
    REFERENCES facturas(id);

ALTER TABLE detalles
    ADD CONSTRAINT FK_Detalles_Articulos
    FOREIGN KEY (id_articulo)
    REFERENCES articulos(id);

ALTER TABLE detalles
    ADD CONSTRAINT U_Detalle_id
    UNIQUE(id_articulo, id_factura);
    














